const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');
const FormData = require('form-data');

const app = express();

const PORT = process.env.PORT || 3005;

// Middleware to parse JSON bodies
app.use(bodyParser.json());
app.use(cors());

// Function to create an opportunity in Lead Docket
const createOpportunity = async (callerID, title) => {
    const data = new URLSearchParams();
    data.append('First', 'Unknown'); 
    data.append('Last', 'Unknown');  
    data.append('Phone', callerID);
    data.append('Email', ''); 
    data.append('Summary', `Call from ${callerID} - ${title}`);

    const createOpportunityURL = 'https://morrellfirm.leaddocket.com/opportunities/form/3?apikey=deb3338b';

    try {
        const response = await axios.post(createOpportunityURL, data.toString(), {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        });
        
        // Log the response from Lead Docket
        console.log('Lead Docket Response (Opportunity Creation):', response.data);

        if (response.data.success) {
            console.log('Opportunity created with ID:', response.data.opportunityId);
            return response.data.opportunityId;
        } else {
            console.error('Opportunity creation failed:', response.data.message);
            return null;
        }
    } catch (error) {
        console.error('Error creating opportunity:', error.response ? error.response.data : error.message);
        return null;
    }
};

// Function to attach a file (recording) to an opportunity in Lead Docket
const attachFileToOpportunity = async (opportunityId, fileUrl) => {
    const form = new FormData();
    form.append('Files', fileUrl); // Add the recording URL

    const uploadFileURL = `https://morrellfirm.leaddocket.com/opportunities/uploadfiles?opportunityId=${opportunityId}&apikey=deb3338b&CreatedBy=Opportunity%20API`;

    try {
        const response = await axios.post(uploadFileURL, form, {
            headers: {
                ...form.getHeaders(),
            },
        });

        // Log the response from Lead Docket
        console.log('Lead Docket Response (File Attachment):', response.data);

        if (response.data.success) {
            console.log('File attached successfully');
        } else {
            console.error('File attachment failed:', response.data.message);
        }
    } catch (error) {
        console.error('Error attaching file to opportunity:', error.response ? error.response.data : error.message);
    }
};

// POST route to handle incoming webhook requests
app.post('*', async (req, res) => {
    console.log('Webhook received:', req.body); // Log the incoming webhook

    const { event, callerid, finishtype, title, FILES } = req.body;

    try {
        // Condition 1: Missed Call
        if (event === 'incoming' && finishtype === 'Missed') {
            console.log('Missed call detected, creating opportunity...');
            const opportunityId = await createOpportunity(callerid, title);
            if (!opportunityId) {
                return res.status(500).send('Failed to create opportunity for missed call.');
            }
        }

        // Condition 2: Completed Call with Recording
        if (event === 'incoming' && finishtype === 'Ok' && FILES && FILES.length > 0) {
            console.log('Completed call with recording detected, creating opportunity and attaching file...');
            const opportunityId = await createOpportunity(callerid, title);
            if (opportunityId) {
                const fileUrl = FILES[0]; // Use the first recording URL
                await attachFileToOpportunity(opportunityId, fileUrl);
            } else {
                return res.status(500).send('Failed to create opportunity for completed call.');
            }
        }

        res.status(200).send('Webhook processed successfully!'); // Send success response
    } catch (error) {
        console.error('Error processing webhook:', error);
        res.status(500).send('Error processing webhook.');
    }
});

// Specific GET route for the root ('/')
app.get('/', (req, res) => {
    res.send('Hello from the Express server!');
});

// Fallback route for all other GET requests
app.get('*', (req, res) => {
    console.log('GET request received:', {
        params: req.params,
        headers: req.headers,
        body: req.body,
    });
    res.send('Hello from the server!');
});


app.listen(3005, () => {
    console.log('Server running on port 3000');
  });
  
  module.exports = app;
